﻿$Appx = Get-AppxPackage | select name
$appx | Out-File -FilePath C:\temp\Appx.txt
