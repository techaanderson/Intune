read-host -AsSecureString | ConvertFrom-SecureString
